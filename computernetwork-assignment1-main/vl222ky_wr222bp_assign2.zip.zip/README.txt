# ComputerNetwork-Assignment2

in order to run this program, you will need to open your shell in the working directory.
then run the command "java Main 8080 public". This command will run the server on the port 8080 and
make sure public is in the right directory. If the public folder has been moved inside another folder in the 
working directory, then you will need to edit the command to where ever your public folder now is.